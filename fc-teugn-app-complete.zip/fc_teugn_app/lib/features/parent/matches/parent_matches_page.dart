import 'package:flutter/material.dart';

class ParentMatchesPage extends StatelessWidget {
  const ParentMatchesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ParentMatchesPage')),
      body: const Center(child: Text('Stub: ParentMatchesPage')),
    );
  }
}
