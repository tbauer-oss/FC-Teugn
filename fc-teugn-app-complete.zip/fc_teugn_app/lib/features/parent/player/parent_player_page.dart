import 'package:flutter/material.dart';

class ParentPlayerPage extends StatelessWidget {
  const ParentPlayerPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ParentPlayerPage')),
      body: const Center(child: Text('Stub: ParentPlayerPage')),
    );
  }
}
