import 'package:flutter/material.dart';

class ParentTrainingsPage extends StatelessWidget {
  const ParentTrainingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ParentTrainingsPage')),
      body: const Center(child: Text('Stub: ParentTrainingsPage')),
    );
  }
}
