import 'package:flutter/material.dart';

class CoachTrainingsPage extends StatelessWidget {
  const CoachTrainingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CoachTrainingsPage')),
      body: const Center(child: Text('Stub: CoachTrainingsPage')),
    );
  }
}
