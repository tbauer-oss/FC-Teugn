import 'package:flutter/material.dart';

class CoachPlayersPage extends StatelessWidget {
  const CoachPlayersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CoachPlayersPage')),
      body: const Center(child: Text('Stub: CoachPlayersPage')),
    );
  }
}
