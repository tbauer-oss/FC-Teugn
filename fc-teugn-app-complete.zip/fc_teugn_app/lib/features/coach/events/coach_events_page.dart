import 'package:flutter/material.dart';

class CoachEventsPage extends StatelessWidget {
  const CoachEventsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CoachEventsPage')),
      body: const Center(child: Text('Stub: CoachEventsPage')),
    );
  }
}
