import 'package:flutter/material.dart';

class CoachMatchesPage extends StatelessWidget {
  const CoachMatchesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CoachMatchesPage')),
      body: const Center(child: Text('Stub: CoachMatchesPage')),
    );
  }
}
